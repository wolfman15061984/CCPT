
# Currency Tracker App

A responsive web app built with React + Vite that tracks live prices of fiat and crypto currencies. Features include:

- Live price updates for all major currencies
- Currency converter
- Light/Dark mode
- Interactive charts (price trends)
- Favorites system
- Language switcher (English/Arabic)
- Progressive Web App (PWA) support for installable experience

## Coming Soon
- Login system
- Alerts and notifications
- Monthly subscription support

## Setup

```bash
npm install
npm run dev
```

## Deploy to Netlify
1. Push this repo to GitHub
2. Connect your GitHub account on Netlify
3. Select this repo and follow the Netlify steps

Enjoy!
